# Code of Conduct

Participation in this repository requires compliance with the [GSMP Code of Conduct](https://www.gs1.org/standards/gsmp-manual/current-standard#27-Appendix:-GSMP-Participation-Requirements,-Code-of-Conduct,-Conflict-Management-Rules-and-Suspension-of-a-Participant+27-2-GSMP-Code-of-Conduct).
