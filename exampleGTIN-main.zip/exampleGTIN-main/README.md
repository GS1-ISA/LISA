# Example GTIN
The landing page for the example GTIN 09506000149301
