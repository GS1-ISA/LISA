# 2d-barcode-demonstrator
A tool for generating 2D barcodes with AI syntax and GS1 Digital Link URIs.

This is for demo use only and **not** to be used to generate barcodes for use on actual products. It exists primarily to show the different syntaxes defined in the GS1 system and how these are independent of the choice of data carrier.

A [demo](https://gs1.github.io/2d-barcode-generator/) is available.
