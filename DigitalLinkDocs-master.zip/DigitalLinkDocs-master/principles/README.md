# 11 Transferable Principles of GS1 Digital Link
This repository supports the publication of the [11 Transferable Principles of GS1 Digital Link](https://gs1.github.io/DigitalLinkDocs/principles/) which is designed to promote those principles in other standards work outside GS1.

Please note that the images in this directory were obtained from Flickr and are used under Creative Commons licensing. Please see the primary document (the index.html file) for details.
