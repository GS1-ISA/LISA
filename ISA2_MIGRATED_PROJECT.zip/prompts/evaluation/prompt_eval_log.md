# Prompt Evaluatie Resultaten

| Eval ID | Prompt ID | Relevantie | Precisie | Kosten | Opmerkingen |
|---------|-----------|------------|----------|--------|-------------|
| EVAL-0001 | PR-001 | 4.5 | 4.2 | medium | Goede structuur, verbeterbare formatting |
