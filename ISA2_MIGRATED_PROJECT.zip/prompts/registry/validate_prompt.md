# Prompt: Standard Validation

Valideer of een gegeven dataset, term of standaard conform is aan GS1-richtlijnen.