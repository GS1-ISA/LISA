# Prompt: Knowledge Graph Query

Gebruik de kennisgraaf om standaarden of attributen te verklaren, inclusief relaties.