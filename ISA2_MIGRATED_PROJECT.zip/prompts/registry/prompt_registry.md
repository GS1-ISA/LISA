# Prompt Registry (start)

| Prompt ID | Titel | Doel | Versie | Laatst gebruikt | Evaluatie ID |
|-----------|-------|------|--------|------------------|---------------|
| PR-001 | vector_ingest_summarizer | Samenvatten van documenten voor vectorisatie | v1.0 | — | pending |
| PR-002 | isa_tool_usage | Instructieprompt voor toolgebruik in agent | v1.0 | — | pending |
