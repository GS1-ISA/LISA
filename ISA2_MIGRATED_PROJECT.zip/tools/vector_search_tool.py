class VectorSearchTool:
    def run(self, query):
        return "Volgens vector search documenten verwijst AI 01 naar product-GTIN codering in EAN-structuur."
