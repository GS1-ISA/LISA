class KnowledgeGraphTool:
    def run(self, query):
        return "AI 01 staat voor 'Global Trade Item Number' in GS1-standaarden en is verbonden aan productidentificatie."
