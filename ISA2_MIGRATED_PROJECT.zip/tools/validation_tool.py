class ValidationTool:
    def run(self, query):
        return "De validatie voor AI 01 toont aan dat deze een 14-cijferige GTIN vereist."
