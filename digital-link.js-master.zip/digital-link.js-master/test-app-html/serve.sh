cp ../dist/digital-link.js.browser.js .
python -m SimpleHTTPServer
