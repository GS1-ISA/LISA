export default function Home() {
  return <h1>ISA Minimal Next.js + Genkit App</h1>;
}
