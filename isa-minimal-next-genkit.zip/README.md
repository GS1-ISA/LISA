# ISA Minimal Next.js + Genkit App

This is a minimal Firebase-ready project for the ISA development environment using Next.js 15 and Genkit 1.8.0.

## Setup

1. Run `npm install`
2. Run `firebase login`
3. Run `firebase use --add` (select `isa-firebase-5cf2f`)
4. Run `firebase deploy --only hosting`
