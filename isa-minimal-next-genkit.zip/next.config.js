module.exports = {
  experimental: {
    serverActions: true
  }
}