This directory contains a basic Docker-based build system intended for use by maintainers of the package repository.
