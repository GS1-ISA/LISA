// Empty config file needed for running jest-cli
